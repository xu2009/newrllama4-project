#include <Rcpp.h>
#include "proxy.h"
#include <dlfcn.h>

using namespace Rcpp;

// --- Helper for error checking ---
void check_error(newrllama_error_code code, const char* error_message) {
    if (code != NEWRLLAMA_SUCCESS) {
        stop(error_message ? error_message : "An unknown error occurred in the backend C-API.");
    }
}

// --- Finalizers for XPtr ---
// These functions are passed to XPtr to handle resource cleanup.
extern "C" void model_finalizer(newrllama_model_handle handle) {
    if (handle && newrllama_api.model_free) {
        newrllama_api.model_free(handle);
    }
}
extern "C" void context_finalizer(newrllama_context_handle handle) {
    if (handle && newrllama_api.context_free) {
        newrllama_api.context_free(handle);
    }
}

// ------------------------------------
// --- R-Exported Wrapper Functions ---
// ------------------------------------

extern "C" {

void r_newrllama_api_init(SEXP path_sexp) {
    if (TYPEOF(path_sexp) != STRSXP || LENGTH(path_sexp) != 1) {
        stop("Expected character string for library path");
    }
    
    const char* lib_path = CHAR(STRING_ELT(path_sexp, 0));
    if (!lib_path || strlen(lib_path) == 0) {
        stop("Invalid library path");
    }
    
    // 使用RTLD_DEFAULT来查找已经由R加载的符号
    // 然后如果失败，尝试用RTLD_GLOBAL重新打开
    void* handle = RTLD_DEFAULT;
    bool success = newrllama_api_init(handle);
    
    if (!success) {
        // 如果RTLD_DEFAULT失败，尝试明确加载库
        handle = dlopen(lib_path, RTLD_LAZY | RTLD_GLOBAL);
        if (!handle) {
            const char* error = dlerror();
            stop(std::string("Failed to open library: ") + (error ? error : "unknown error"));
        }
        
        success = newrllama_api_init(handle);
        if (!success) {
            dlclose(handle);
            stop("Failed to initialize newrllama API: unable to load required symbols");
        }
    }
}

SEXP r_backend_init() {
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    const char* error_message = nullptr;
    check_error(newrllama_api.backend_init(&error_message), error_message);
    return R_NilValue;
}

SEXP r_backend_free() {
    if (newrllama_api.backend_free) {
        newrllama_api.backend_free();
    }
    return R_NilValue;
}

SEXP r_model_load(SEXP model_path, SEXP n_gpu_layers, SEXP use_mmap, SEXP use_mlock) {
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    std::string model_path_str = as<std::string>(model_path);
    int n_gpu_layers_int = as<int>(n_gpu_layers);
    bool use_mmap_bool = as<bool>(use_mmap);
    bool use_mlock_bool = as<bool>(use_mlock);
    
    const char* error_message = nullptr;
    newrllama_model_handle handle = nullptr;
    check_error(newrllama_api.model_load(model_path_str.c_str(), n_gpu_layers_int, use_mmap_bool, use_mlock_bool, &handle, &error_message), error_message);

    // Create XPtr with custom finalizer using R's C API  
    Rcpp::XPtr<void> p(handle, false);  // don't use default delete
    p.attr("class") = "newrllama_model";
    R_RegisterCFinalizerEx(p, (R_CFinalizer_t)model_finalizer, TRUE);
    return p;
}

SEXP r_context_create(SEXP model_ptr, SEXP n_ctx, SEXP n_threads, SEXP n_seq_max) {
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    Rcpp::XPtr<void> model_xptr(model_ptr);
    newrllama_model_handle model = static_cast<newrllama_model_handle>(model_xptr.get());
    int n_ctx_int = as<int>(n_ctx);
    int n_threads_int = as<int>(n_threads);
    int n_seq_max_int = as<int>(n_seq_max);
    const char* error_message = nullptr;
    newrllama_context_handle handle = nullptr;
    check_error(newrllama_api.context_create(model, n_ctx_int, n_threads_int, n_seq_max_int, &handle, &error_message), error_message);
    
    // Create XPtr with custom finalizer using R's C API
    Rcpp::XPtr<void> p(handle, false);  // don't use default delete
    p.attr("class") = "newrllama_context";
    R_RegisterCFinalizerEx(p, (R_CFinalizer_t)context_finalizer, TRUE);
    return p;
}

SEXP r_tokenize(SEXP model_ptr, SEXP text, SEXP add_special) {
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    
    // Convert SEXP parameters to C++ types
    XPtr<void> model_xptr(model_ptr);
    newrllama_model_handle model = static_cast<newrllama_model_handle>(model_xptr.get());
    std::string text_str = as<std::string>(text);
    bool add_special_bool = as<bool>(add_special);
    
    // Use aligned storage for better memory alignment
    alignas(8) const char* error_message = nullptr;
    alignas(8) int32_t* tokens_c = nullptr;
    alignas(8) size_t n_tokens_c = 0;
    
    // Call the API function
    newrllama_error_code result = newrllama_api.tokenize(model, text_str.c_str(), add_special_bool, &tokens_c, &n_tokens_c, &error_message);
    check_error(result, error_message);
    
    // Safely copy tokens to avoid alignment issues
    IntegerVector tokens_r(n_tokens_c);
    for (size_t i = 0; i < n_tokens_c; ++i) {
        tokens_r[i] = tokens_c[i];
    }
    
    if (newrllama_api.free_tokens) {
        newrllama_api.free_tokens(tokens_c);
    }
    return tokens_r;
}

SEXP r_detokenize(SEXP model_ptr, SEXP tokens) {
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    XPtr<void> model_xptr(model_ptr);
    newrllama_model_handle model = static_cast<newrllama_model_handle>(model_xptr.get());
    IntegerVector tokens_vec = as<IntegerVector>(tokens);
    const char* error_message = nullptr;
    char* text_c = nullptr;
    std::vector<int32_t> tokens_cpp = as<std::vector<int32_t>>(tokens_vec);
    check_error(newrllama_api.detokenize(model, tokens_cpp.data(), tokens_cpp.size(), &text_c, &error_message), error_message);
    std::string result(text_c);
    if (newrllama_api.free_string) {
        newrllama_api.free_string(text_c);
    }
    return CharacterVector::create(result);
}

SEXP r_apply_chat_template(SEXP model_ptr, SEXP tmpl, SEXP chat_messages, SEXP add_ass) {
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    XPtr<void> model_xptr(model_ptr);
    newrllama_model_handle model = static_cast<newrllama_model_handle>(model_xptr.get());
    List chat_messages_list = as<List>(chat_messages);
    bool add_ass_bool = as<bool>(add_ass);
    
    std::vector<newrllama_chat_message> messages_c(chat_messages_list.size());
    std::vector<std::string> roles, contents;
    roles.reserve(chat_messages_list.size());
    contents.reserve(chat_messages_list.size());
    for(size_t i = 0; i < chat_messages_list.size(); ++i) {
        List msg = chat_messages_list[i];
        roles.push_back(as<std::string>(msg["role"]));
        contents.push_back(as<std::string>(msg["content"]));
        messages_c[i] = {roles.back().c_str(), contents.back().c_str()};
    }
    std::string tmpl_str;
    const char* tmpl_c = nullptr;
    if (!Rf_isNull(tmpl)) {
        tmpl_str = as<std::string>(tmpl);
        tmpl_c = tmpl_str.c_str();
    }
    char* result_c = nullptr;
    const char* error_message = nullptr;
    check_error(newrllama_api.apply_chat_template(model, tmpl_c, messages_c.data(), messages_c.size(), add_ass_bool, &result_c, &error_message), error_message);
    std::string result(result_c);
    if (newrllama_api.free_string) {
        newrllama_api.free_string(result_c);
    }
    return CharacterVector::create(result);
}

SEXP r_generate(SEXP ctx_ptr, SEXP tokens, SEXP max_tokens, SEXP top_k, SEXP top_p, SEXP temperature, SEXP repeat_last_n, SEXP penalty_repeat, SEXP seed) {
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    XPtr<void> ctx_xptr(ctx_ptr);
    newrllama_context_handle ctx = static_cast<newrllama_context_handle>(ctx_xptr.get());
    IntegerVector tokens_vec = as<IntegerVector>(tokens);
    std::vector<int32_t> tokens_in = as<std::vector<int32_t>>(tokens_vec);
    int max_tokens_int = as<int>(max_tokens);
    int top_k_int = as<int>(top_k);
    float top_p_float = as<float>(top_p);
    float temperature_float = as<float>(temperature);
    int repeat_last_n_int = as<int>(repeat_last_n);
    float penalty_repeat_float = as<float>(penalty_repeat);
    int seed_int = as<int>(seed);
    
    char* result_c = nullptr;
    const char* error_message = nullptr;
    check_error(newrllama_api.generate(ctx, tokens_in.data(), tokens_in.size(), max_tokens_int, top_k_int, top_p_float, temperature_float, repeat_last_n_int, penalty_repeat_float, seed_int, &result_c, &error_message), error_message);
    std::string result(result_c);
    if (newrllama_api.free_string) {
        newrllama_api.free_string(result_c);
    }
    return CharacterVector::create(result);
}

SEXP r_generate_parallel(SEXP ctx_ptr, SEXP prompts, SEXP max_tokens, SEXP top_k, SEXP top_p, SEXP temperature, SEXP repeat_last_n, SEXP penalty_repeat, SEXP seed) {
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    XPtr<void> ctx_xptr(ctx_ptr);
    newrllama_context_handle ctx = static_cast<newrllama_context_handle>(ctx_xptr.get());
    CharacterVector prompts_vec = as<CharacterVector>(prompts);
    int max_tokens_int = as<int>(max_tokens);
    int top_k_int = as<int>(top_k);
    float top_p_float = as<float>(top_p);
    float temperature_float = as<float>(temperature);
    int repeat_last_n_int = as<int>(repeat_last_n);
    float penalty_repeat_float = as<float>(penalty_repeat);
    int seed_int = as<int>(seed);
    
    std::vector<std::string> prompts_str(prompts_vec.size());
    std::vector<const char*> prompts_c(prompts_vec.size());
    for(int i = 0; i < prompts_vec.size(); ++i) {
        prompts_str[i] = as<std::string>(prompts_vec[i]);
        prompts_c[i] = prompts_str[i].c_str();
    }
    struct newrllama_parallel_params params = {max_tokens_int, top_k_int, top_p_float, temperature_float, repeat_last_n_int, penalty_repeat_float, seed_int};
    char** results_c = nullptr;
    const char* error_message = nullptr;
    check_error(newrllama_api.generate_parallel(ctx, prompts_c.data(), prompts_vec.size(), &params, &results_c, &error_message), error_message);
    CharacterVector results_r(prompts_vec.size());
    for (int i = 0; i < prompts_vec.size(); ++i) {
        results_r[i] = results_c[i];
    }
    if (newrllama_api.free_string_array) {
        newrllama_api.free_string_array(results_c, prompts_vec.size());
    }
    return results_r;
}


// --- Vocab Wrappers ---
SEXP r_token_get_text(SEXP model_ptr, SEXP token_sexp) {
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    XPtr<void> model_xptr(model_ptr);
    newrllama_model_handle model = static_cast<newrllama_model_handle>(model_xptr.get());
    int token = as<int>(token_sexp);
    char* text_c = nullptr;
    const char* error_message = nullptr;
    check_error(newrllama_api.token_get_text(model, token, &text_c, &error_message), error_message);
    std::string text(text_c);
    if (newrllama_api.free_string) {
        newrllama_api.free_string(text_c);
    }
    return CharacterVector::create(text);
}

#define WRAP_TOKEN_FUNC_INT(F_NAME, API_MEMBER) \
    SEXP F_NAME(SEXP model_ptr) { \
        if (!newrllama_api_is_loaded()) { \
            stop("Backend library is not loaded. Please run install_newrllama() first."); \
        } \
        XPtr<void> model_xptr(model_ptr); \
        newrllama_model_handle model = static_cast<newrllama_model_handle>(model_xptr.get()); \
        int result = newrllama_api.API_MEMBER(model); \
        return IntegerVector::create(result); \
    }

#define WRAP_TOKEN_FUNC_BOOL(F_NAME, API_MEMBER) \
    SEXP F_NAME(SEXP model_ptr) { \
        if (!newrllama_api_is_loaded()) { \
            stop("Backend library is not loaded. Please run install_newrllama() first."); \
        } \
        XPtr<void> model_xptr(model_ptr); \
        newrllama_model_handle model = static_cast<newrllama_model_handle>(model_xptr.get()); \
        bool result = newrllama_api.API_MEMBER(model); \
        return LogicalVector::create(result); \
    }

WRAP_TOKEN_FUNC_INT(r_token_bos, token_bos)
WRAP_TOKEN_FUNC_INT(r_token_eos, token_eos)
WRAP_TOKEN_FUNC_INT(r_token_sep, token_sep)
WRAP_TOKEN_FUNC_INT(r_token_nl, token_nl)
WRAP_TOKEN_FUNC_INT(r_token_pad, token_pad)
WRAP_TOKEN_FUNC_INT(r_token_eot, token_eot)
WRAP_TOKEN_FUNC_BOOL(r_add_bos_token, add_bos_token)
WRAP_TOKEN_FUNC_BOOL(r_add_eos_token, add_eos_token)
WRAP_TOKEN_FUNC_INT(r_token_fim_pre, token_fim_pre)
WRAP_TOKEN_FUNC_INT(r_token_fim_mid, token_fim_mid)
WRAP_TOKEN_FUNC_INT(r_token_fim_suf, token_fim_suf)

SEXP r_token_get_attr(SEXP model_ptr, SEXP token_sexp) { 
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    XPtr<void> model_xptr(model_ptr);
    newrllama_model_handle model = static_cast<newrllama_model_handle>(model_xptr.get());
    int token = as<int>(token_sexp);
    int result = newrllama_api.token_get_attr(model, token);
    return IntegerVector::create(result);
}

SEXP r_token_get_score(SEXP model_ptr, SEXP token_sexp) { 
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    XPtr<void> model_xptr(model_ptr);
    newrllama_model_handle model = static_cast<newrllama_model_handle>(model_xptr.get());
    int token = as<int>(token_sexp);
    double result = newrllama_api.token_get_score(model, token);
    return NumericVector::create(result);
}

SEXP r_token_is_eog(SEXP model_ptr, SEXP token_sexp) { 
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    int token = as<int>(token_sexp);
    bool result = newrllama_api.token_is_eog(XPtr<llama_model>(model_ptr).get(), token);
    return LogicalVector::create(result);
}

SEXP r_token_is_control(SEXP model_ptr, SEXP token_sexp) { 
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    int token = as<int>(token_sexp);
    bool result = newrllama_api.token_is_control(XPtr<llama_model>(model_ptr).get(), token);
    return LogicalVector::create(result);
}

// 新增：重置函数指针的R接口（用于清理）
void r_newrllama_api_reset() {
    newrllama_api_reset();
}

// Simplified tokenize test function to diagnose alignment issues
SEXP r_tokenize_test(SEXP model_ptr) {
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    
    // Simple test - try to call tokenize with hardcoded parameters
    XPtr<void> model_xptr(model_ptr);
    newrllama_model_handle model = static_cast<newrllama_model_handle>(model_xptr.get());
    
    // Use simple hardcoded parameters to minimize complexity
    const char* test_text = "H";
    bool add_special = false;
    
    // Declare variables with explicit alignment
    int32_t* tokens_c = nullptr;
    size_t n_tokens_c = 0;
    const char* error_message = nullptr;
    
    // Try the API call
    newrllama_error_code result = newrllama_api.tokenize(
        model, 
        test_text, 
        add_special, 
        &tokens_c, 
        &n_tokens_c, 
        &error_message
    );
    
    if (result != NEWRLLAMA_SUCCESS) {
        if (error_message) {
            stop("Tokenize failed: %s", error_message);
        } else {
            stop("Tokenize failed with unknown error");
        }
    }
    
    // Create result vector
    IntegerVector tokens_r(n_tokens_c);
    for (size_t i = 0; i < n_tokens_c; ++i) {
        tokens_r[i] = tokens_c[i];
    }
    
    // Cleanup
    if (newrllama_api.free_tokens) {
        newrllama_api.free_tokens(tokens_c);
    }
    
    return tokens_r;
}

} // extern "C" 
