# --- FILE: newrllama4/R/zzz.R ---

# 用于存储动态库信息的环境
.pkg_env <- new.env(parent = emptyenv())

.onLoad <- function(libname, pkgname) {
  if (lib_is_installed()) {
    full_lib_path <- get_lib_path()
    
    # 尝试全局加载库，让符号在所有DLL中可用
    tryCatch({
      .pkg_env$lib <- dyn.load(full_lib_path, local = FALSE, now = TRUE)
      
      # !! 新增步骤：初始化C++层的函数指针 !!
      # 获取动态库的句柄并初始化API函数指针
      tryCatch({
        # 使用dyn.load返回的DLL信息来初始化API
        # 我们传递库的路径，C++端会重新打开它来获取句柄
        .Call("c_newrllama_api_init", full_lib_path)
        
        packageStartupMessage("✅ newrllama backend library loaded and API initialized successfully")
      }, error = function(e) {
        packageStartupMessage("⚠️ Warning: Backend library loaded but API initialization failed: ", e$message)
        packageStartupMessage("The library may still work, but some functions might not be available.")
      })
      
    }, error = function(e) {
      packageStartupMessage("⚠️ Warning: Failed to load backend library: ", e$message)
      packageStartupMessage("Please try reinstalling with: install_newrllama()")
    })
    
  } else {
    # 仅在交互式会话中显示消息，避免安装时的干扰
    if (interactive()) {
      packageStartupMessage(
        "Welcome to newrllama4! The backend library is not yet installed.\n",
        "Please run `install_newrllama()` to download and set it up."
      )
    }
  }
}

.onUnload <- function(libpath) {
  if (!is.null(.pkg_env$lib)) {
    tryCatch({
      # 清理函数指针（如果函数可用的话）
      tryCatch(.Call("c_newrllama_api_reset"), error = function(e) {})
      dyn.unload(.pkg_env$lib[["path"]])
    }, error = function(e) {
      # 静默处理卸载错误
    })
  }
}

# 辅助函数：检查库是否已加载
.is_backend_loaded <- function() {
  !is.null(.pkg_env$lib)
}

# 辅助函数：确保库已加载
.ensure_backend_loaded <- function() {
  if (!.is_backend_loaded()) {
    if (lib_is_installed()) {
      # 尝试重新加载
      .onLoad(libname = "newrllama4", pkgname = "newrllama4")
    }
    
    if (!.is_backend_loaded()) {
      stop("Backend library is not loaded. Please run install_newrllama() first.", call. = FALSE)
    }
  }
} 