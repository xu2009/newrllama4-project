#include <Rcpp.h>
#include "proxy.h"
#include <dlfcn.h>

using namespace Rcpp;

// --- Helper for error checking ---
void check_error(newrllama_error_code code, const char* error_message) {
    if (code != NEWRLLAMA_SUCCESS) {
        stop(error_message ? error_message : "An unknown error occurred in the backend C-API.");
    }
}

// --- Finalizers for XPtr ---
// These functions are passed to XPtr to handle resource cleanup.
extern "C" void model_finalizer(newrllama_model_handle handle) {
    if (handle && newrllama_api.model_free) {
        newrllama_api.model_free(handle);
    }
}
extern "C" void context_finalizer(newrllama_context_handle handle) {
    if (handle && newrllama_api.context_free) {
        newrllama_api.context_free(handle);
    }
}

// ------------------------------------
// --- R-Exported Wrapper Functions ---
// ------------------------------------

extern "C" {

void r_newrllama_api_init(SEXP path_sexp) {
    if (TYPEOF(path_sexp) != STRSXP || LENGTH(path_sexp) != 1) {
        stop("Expected character string for library path");
    }
    
    const char* lib_path = CHAR(STRING_ELT(path_sexp, 0));
    if (!lib_path || strlen(lib_path) == 0) {
        stop("Invalid library path");
    }
    
    // 使用RTLD_DEFAULT来查找已经由R加载的符号
    // 然后如果失败，尝试用RTLD_GLOBAL重新打开
    void* handle = RTLD_DEFAULT;
    bool success = newrllama_api_init(handle);
    
    if (!success) {
        // 如果RTLD_DEFAULT失败，尝试明确加载库
        handle = dlopen(lib_path, RTLD_LAZY | RTLD_GLOBAL);
        if (!handle) {
            const char* error = dlerror();
            stop(std::string("Failed to open library: ") + (error ? error : "unknown error"));
        }
        
        success = newrllama_api_init(handle);
        if (!success) {
            dlclose(handle);
            stop("Failed to initialize newrllama API: unable to load required symbols");
        }
    }
}

SEXP r_backend_init() {
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    const char* error_message = nullptr;
    check_error(newrllama_api.backend_init(&error_message), error_message);
    return R_NilValue;
}

SEXP r_backend_free() {
    if (newrllama_api.backend_free) {
        newrllama_api.backend_free();
    }
    return R_NilValue;
}

SEXP r_model_load(SEXP model_path, SEXP n_gpu_layers, SEXP use_mmap, SEXP use_mlock) {
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    std::string model_path_str = as<std::string>(model_path);
    int n_gpu_layers_int = as<int>(n_gpu_layers);
    bool use_mmap_bool = as<bool>(use_mmap);
    bool use_mlock_bool = as<bool>(use_mlock);
    
    const char* error_message = nullptr;
    newrllama_model_handle handle = nullptr;
    check_error(newrllama_api.model_load(model_path_str.c_str(), n_gpu_layers_int, use_mmap_bool, use_mlock_bool, &handle, &error_message), error_message);

    // Create XPtr with custom finalizer using R's C API
    Rcpp::XPtr<llama_model> p(handle, false);  // don't use default delete
    p.attr("class") = "newrllama_model";
    R_RegisterCFinalizerEx(p, (R_CFinalizer_t)model_finalizer, TRUE);
    return p;
}

SEXP r_context_create(SEXP model_ptr, int n_ctx, int n_threads, int n_seq_max) {
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    Rcpp::XPtr<llama_model> model(model_ptr);
    const char* error_message = nullptr;
    newrllama_context_handle handle = nullptr;
    check_error(newrllama_api.context_create(model.get(), n_ctx, n_threads, n_seq_max, &handle, &error_message), error_message);
    
    // Create XPtr with custom finalizer using R's C API
    Rcpp::XPtr<llama_context> p(handle, false);  // don't use default delete
    p.attr("class") = "newrllama_context";
    R_RegisterCFinalizerEx(p, (R_CFinalizer_t)context_finalizer, TRUE);
    return p;
}

IntegerVector r_tokenize(SEXP model_ptr, std::string text, bool add_special) {
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    XPtr<llama_model> model(model_ptr);
    const char* error_message = nullptr;
    int32_t* tokens_c = nullptr;
    size_t n_tokens_c = 0;
    check_error(newrllama_api.tokenize(model.get(), text.c_str(), add_special, &tokens_c, &n_tokens_c, &error_message), error_message);
    IntegerVector tokens_r(tokens_c, tokens_c + n_tokens_c);
    if (newrllama_api.free_tokens) {
        newrllama_api.free_tokens(tokens_c);
    }
    return tokens_r;
}

std::string r_detokenize(SEXP model_ptr, IntegerVector tokens) {
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    XPtr<llama_model> model(model_ptr);
    const char* error_message = nullptr;
    char* text_c = nullptr;
    std::vector<int32_t> tokens_vec = as<std::vector<int32_t>>(tokens);
    check_error(newrllama_api.detokenize(model.get(), tokens_vec.data(), tokens_vec.size(), &text_c, &error_message), error_message);
    std::string result(text_c);
    if (newrllama_api.free_string) {
        newrllama_api.free_string(text_c);
    }
    return result;
}

std::string r_apply_chat_template(SEXP model_ptr, Nullable<String> tmpl, List chat_messages, bool add_ass) {
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    XPtr<llama_model> model(model_ptr);
    std::vector<newrllama_chat_message> messages_c(chat_messages.size());
    std::vector<std::string> roles, contents;
    roles.reserve(chat_messages.size());
    contents.reserve(chat_messages.size());
    for(size_t i = 0; i < chat_messages.size(); ++i) {
        List msg = chat_messages[i];
        roles.push_back(as<std::string>(msg["role"]));
        contents.push_back(as<std::string>(msg["content"]));
        messages_c[i] = {roles.back().c_str(), contents.back().c_str()};
    }
    std::string tmpl_str;
    const char* tmpl_c = nullptr;
    if (tmpl.isNotNull()) {
        tmpl_str = as<std::string>(tmpl.get());
        tmpl_c = tmpl_str.c_str();
    }
    char* result_c = nullptr;
    const char* error_message = nullptr;
    check_error(newrllama_api.apply_chat_template(model.get(), tmpl_c, messages_c.data(), messages_c.size(), add_ass, &result_c, &error_message), error_message);
    std::string result(result_c);
    if (newrllama_api.free_string) {
        newrllama_api.free_string(result_c);
    }
    return result;
}

std::string r_generate(SEXP ctx_ptr, IntegerVector tokens, int max_tokens, int top_k, float top_p, float temperature, int repeat_last_n, float penalty_repeat, int seed) {
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    XPtr<llama_context> ctx(ctx_ptr);
    std::vector<int32_t> tokens_in = as<std::vector<int32_t>>(tokens);
    char* result_c = nullptr;
    const char* error_message = nullptr;
    check_error(newrllama_api.generate(ctx.get(), tokens_in.data(), tokens_in.size(), max_tokens, top_k, top_p, temperature, repeat_last_n, penalty_repeat, seed, &result_c, &error_message), error_message);
    std::string result(result_c);
    if (newrllama_api.free_string) {
        newrllama_api.free_string(result_c);
    }
    return result;
}

CharacterVector r_generate_parallel(SEXP ctx_ptr, CharacterVector prompts, int max_tokens, int top_k, float top_p, float temperature, int repeat_last_n, float penalty_repeat, int seed) {
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    XPtr<llama_context> ctx(ctx_ptr);
    std::vector<std::string> prompts_str(prompts.size());
    std::vector<const char*> prompts_c(prompts.size());
    for(int i = 0; i < prompts.size(); ++i) {
        prompts_str[i] = as<std::string>(prompts[i]);
        prompts_c[i] = prompts_str[i].c_str();
    }
    struct newrllama_parallel_params params = {max_tokens, top_k, top_p, temperature, repeat_last_n, penalty_repeat, seed};
    char** results_c = nullptr;
    const char* error_message = nullptr;
    check_error(newrllama_api.generate_parallel(ctx.get(), prompts_c.data(), prompts.size(), &params, &results_c, &error_message), error_message);
    CharacterVector results_r(prompts.size());
    for (int i = 0; i < prompts.size(); ++i) {
        results_r[i] = results_c[i];
    }
    if (newrllama_api.free_string_array) {
        newrllama_api.free_string_array(results_c, prompts.size());
    }
    return results_r;
}


// --- Vocab Wrappers ---
SEXP r_token_get_text(SEXP model_ptr, SEXP token_sexp) {
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    XPtr<llama_model> model(model_ptr);
    int token = as<int>(token_sexp);
    char* text_c = nullptr;
    const char* error_message = nullptr;
    check_error(newrllama_api.token_get_text(model.get(), token, &text_c, &error_message), error_message);
    std::string text(text_c);
    if (newrllama_api.free_string) {
        newrllama_api.free_string(text_c);
    }
    return CharacterVector::create(text);
}

#define WRAP_TOKEN_FUNC_INT(F_NAME, API_MEMBER) \
    SEXP F_NAME(SEXP model_ptr) { \
        if (!newrllama_api_is_loaded()) { \
            stop("Backend library is not loaded. Please run install_newrllama() first."); \
        } \
        int result = newrllama_api.API_MEMBER(XPtr<llama_model>(model_ptr).get()); \
        return IntegerVector::create(result); \
    }

#define WRAP_TOKEN_FUNC_BOOL(F_NAME, API_MEMBER) \
    SEXP F_NAME(SEXP model_ptr) { \
        if (!newrllama_api_is_loaded()) { \
            stop("Backend library is not loaded. Please run install_newrllama() first."); \
        } \
        bool result = newrllama_api.API_MEMBER(XPtr<llama_model>(model_ptr).get()); \
        return LogicalVector::create(result); \
    }

WRAP_TOKEN_FUNC_INT(r_token_bos, token_bos)
WRAP_TOKEN_FUNC_INT(r_token_eos, token_eos)
WRAP_TOKEN_FUNC_INT(r_token_sep, token_sep)
WRAP_TOKEN_FUNC_INT(r_token_nl, token_nl)
WRAP_TOKEN_FUNC_INT(r_token_pad, token_pad)
WRAP_TOKEN_FUNC_INT(r_token_eot, token_eot)
WRAP_TOKEN_FUNC_BOOL(r_add_bos_token, add_bos_token)
WRAP_TOKEN_FUNC_BOOL(r_add_eos_token, add_eos_token)
WRAP_TOKEN_FUNC_INT(r_token_fim_pre, token_fim_pre)
WRAP_TOKEN_FUNC_INT(r_token_fim_mid, token_fim_mid)
WRAP_TOKEN_FUNC_INT(r_token_fim_suf, token_fim_suf)

SEXP r_token_get_attr(SEXP model_ptr, SEXP token_sexp) { 
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    int token = as<int>(token_sexp);
    int result = newrllama_api.token_get_attr(XPtr<llama_model>(model_ptr).get(), token);
    return IntegerVector::create(result);
}

SEXP r_token_get_score(SEXP model_ptr, SEXP token_sexp) { 
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    int token = as<int>(token_sexp);
    double result = newrllama_api.token_get_score(XPtr<llama_model>(model_ptr).get(), token);
    return NumericVector::create(result);
}

SEXP r_token_is_eog(SEXP model_ptr, SEXP token_sexp) { 
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    int token = as<int>(token_sexp);
    bool result = newrllama_api.token_is_eog(XPtr<llama_model>(model_ptr).get(), token);
    return LogicalVector::create(result);
}

SEXP r_token_is_control(SEXP model_ptr, SEXP token_sexp) { 
    if (!newrllama_api_is_loaded()) {
        stop("Backend library is not loaded. Please run install_newrllama() first.");
    }
    int token = as<int>(token_sexp);
    bool result = newrllama_api.token_is_control(XPtr<llama_model>(model_ptr).get(), token);
    return LogicalVector::create(result);
}

// 新增：重置函数指针的R接口（用于清理）
void r_newrllama_api_reset() {
    newrllama_api_reset();
}

} // extern "C" 
